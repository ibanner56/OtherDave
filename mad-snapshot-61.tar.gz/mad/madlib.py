#!/usr/bin/python

"""Madlib: Markov Analyzer Disjoints Literate Ideas Boldly

Tools for generating random phrases from grammars,
and generating grammars by analyzing text."""

program_name = "madlib"
program_version = "0.7"

#
# TODO
#
# create a Markov/Chains/Sentences class
#  - Used as an intermediate form between input data and the Grammar class.
#    (eliminates the need to parse anything in Grammar, mostly)
#  - stores sentences and tokens as a list of tuples of strings
#  - has an iterator to generate all chains of length N
#  - has import/export filters for various formats, including
#    word lists, common e-book formats, etc
#

cfg = None

LOGLEVELS=5
ERROR, WARNING, INFO, DEBUG, DATA = range(LOGLEVELS)
def log(level, text):
	if cfg.verbose >= level:
		print text

class Grammar:
	"""The core of madlib.  Performs the following:
		- Stores data representing a regular grammar.
		- Loads/saves grammar files.
		- Generates grammars from text by analyzing the text with Markov chains
		- Generates random phrases within a grammar.
	"""
	def __init__(self, cfg):
		self.cfg = cfg
		self.symbols = {}
		self._special = {}
		self._special_raw = { # FIXME: get rid of this cruft
			# Choose "a" or "an" depending on what comes next..
			r"([Aa])/an ([aeiouAEIOU])":r"\1n \2",
			r"([Aa])/an ([^aeiouAEIOU])":r"\1 \2",
			# Insert newlines if requested...
			r"\\n":"\n",
			# Handle to-upper-case and to-lower-case
			r"\\ua":"A",
			r"\\ub":"B",
			r"\\uc":"C",
			r"\\ud":"D",
			r"\\ue":"E",
			r"\\uf":"F",
			r"\\ug":"G",
			r"\\uh":"H",
			r"\\ui":"I",
			r"\\uj":"J",
			r"\\uk":"K",
			r"\\ul":"L",
			r"\\um":"M",
			r"\\un":"N",
			r"\\uo":"O",
			r"\\up":"P",
			r"\\uq":"Q",
			r"\\ur":"R",
			r"\\us":"S",
			r"\\ut":"T",
			r"\\uu":"U",
			r"\\uv":"V",
			r"\\uw":"W",
			r"\\ux":"X",
			r"\\uy":"Y",
			r"\\uz":"Z",
			r"\\u([^a-z])":r"\1",
			r"\\lA":"a",
			r"\\lB":"b",
			r"\\lC":"c",
			r"\\lD":"d",
			r"\\lE":"e",
			r"\\lF":"f",
			r"\\lG":"g",
			r"\\lH":"h",
			r"\\lI":"i",
			r"\\lJ":"j",
			r"\\lK":"k",
			r"\\lL":"l",
			r"\\lM":"m",
			r"\\lN":"n",
			r"\\lO":"o",
			r"\\lP":"p",
			r"\\lQ":"q",
			r"\\lR":"r",
			r"\\lS":"s",
			r"\\lT":"t",
			r"\\lU":"u",
			r"\\lV":"v",
			r"\\lW":"w",
			r"\\lX":"x",
			r"\\lY":"y",
			r"\\lZ":"z",
			r"\\l([^A-Z])":r"\1",
		}

	def _compile_special(self):
		"Compiles the special replacements dict"
		import re

		for item in self._special_raw.keys():
			comp = re.compile(item)
			self._special[comp] = self._special_raw[item]

	def load(self, path, format="text"):
		"""Loads grammar symbols from a file.
			Supported formats are:
				- text
			"""
		symbol = ""
		grammar = {}

		import sys
		if path in [None, "", "-"]: file = sys.stdin
		else: file = open(path, "rb")
		if not file: return None

		# Read one line at a time
		for line in file.xreadlines():
			#line = line.rstrip()
			while line and line[-1:] in "\n\r": line = line[:-1]
			#log(DEBUG, line)
			if line[:1] == "#": # comment
				continue
			# If it's a new symbol, new dictionary entry.
			elif line[0:3] == ":::":
				symbol = line[3:]
			# Otherwise, it's just a possible replacement for this symbol.
			elif len(line) > 0:
				self.add_chain(symbol, line, force=1)
		return grammar

	def save(self, path, format="text"):
		"""Saves grammar symbols to a file.
			Supported formats are:
				- text
			"""
		import sys, os
		if path in [None, "", "-"]: file = sys.stdout
		else:
			if self.cfg.make_backups  and  os.path.exists(path):
				os.rename(path, path + "~")
			file = open(path, "wb")

		syms = self.symbols.keys()
		syms.sort()
		for left in syms:
			file.write(":::" + left + "\n")
			for right in self.symbols[left]:
				file.write(right + "\n")
			file.write("\n")
		file.close()

	def add_chain(self, left, right, force=0):
		"""Insert a new association (Markov chain) into the grammar.
			Appends "right" to the list of chains allowed for symbol "left".
			Uses "force" and cfg.allow_dupe_tokens to determine whether
			chains are repeatable or if they must be unique.

			Tests...
			Setup:
				>>> import pycfg
				>>> cfg = pycfg.config(program_name)
				>>> cfg.default(allow_dupe_tokens=0)
				>>> g = Grammar(cfg)

			Do basic chains work?
				>>> g.add_chain("one", "two")
				>>> print g
				one: two

			Does allow_dupe_tokens=0 work?
				>>> g.add_chain("one", "two")
				>>> print g
				one: two

			Does force=1 work?
				>>> g.add_chain("one", "two", force=1)
				>>> print g
				one: two
				one: two

			Does allow_dupe_tokens=1 work?
				>>> cfg.allow_dupe_tokens=1
				>>> g.add_chain("one", "two")
				>>> print g
				one: two
				one: two
				one: two
		"""
		try: syms = list(self.symbols[left])
		except KeyError: syms = []
		if force  or  \
				self.cfg.allow_dupe_tokens  or  \
				right not in syms:
			syms.append(right)
			log(DATA, "  add_chain: %s => %s" % (left, right))
			self._prev_sym = left # kludge
		self.symbols[left] = tuple(syms)

	def _revert_prev_sym(self):
		"""Nasty kludge to work around a bug at the end of Markov parsing."""
		self.symbols[self._prev_sym] = self.symbols[self._prev_sym][:-1]
		self._prev_sym = None

	def madlib(self, storyfile=None, text=None):
		r"""Returns a random, grammatically-correct phrase.
			If given a storyfile, a randomized search-and-replace
			will be performed.  Otherwise, the story is assumed to
			be a single word:  __START__

			Tests:
			Setup:
				>>> import pycfg
				>>> cfg = pycfg.config()
				>>> cfg.default(allow_dupe_tokens=1)
				>>> g = Grammar(cfg)

			Do basic replacements work?
				>>> g.add_chain("VERB", "run")
				>>> g.madlib(text="See Bob VERB.")
				'See Bob run.'

			Do nested replacements work?
				>>> g.add_chain("WORD", "VERB")
				>>> g.madlib(text="Word: WORD.")
				'Word: run.'

			Does the _special map work?
				>>> g.madlib(text=r"\uupp\uer")
				'UppEr'
				>>> g.madlib(text=r"\lLO\lWE\lR")
				'lOwEr'
				>>> g.madlib(text=r"a/an mouse and a/an orange")
				'a mouse and an orange'
				>>> g.add_chain("__newline__", r"\n")
				>>> g.madlib(text=r"one__newline__two")
				'one\ntwo'

			Do newlines in the story make it through intact?
				>>> print g.madlib(text="one\ntwo")
				one
				two

			Is the output random?  (this has a small chance of failure)
				>>> for num in range(50):
				...     g.add_chain("__num__", str(num))
				>>> results = [g.madlib(text="__num__") for i in range(20)]
				>>> results.sort()
				>>> results[0] == results[-1]
				False
			"""
		import string
		import re
		import random

		if not self._special:
			self._compile_special()

		# Perhaps display the contents of our grammar...
		log(DATA, "Grammar:\n")
		for sym in self.symbols.keys():
			for value in self.symbols[sym]:
				log(DATA, sym + ": " + value)
		log(DATA, "\nProgress:\n")

		result = ""

		if storyfile: # FIXME: use .xreadlines() later, instead of loading all data
			file = open(storyfile, 'rb')
			lines = file.readlines()
			file.close()
		elif text:
			lines = text.split("\n")
		else:
			lines = ["__START__\n"]

		# Now search and replace randomly through each line in the story
		#for line in file.readlines():
		for line in lines:
			# Search and replace through the line until finished
			done = 0
			while not done:
				done = 1
				#for sym in self.symbols.keys():
				#    while search(sym, line):
				for sym in self.symbols.keys():
					#print "Looking for %s" % sym
					while string.find(line, sym) >= 0:
						log(INFO, line)
						part = string.replace(line, sym, random.choice(self.symbols[sym]), 1)
						#part = re.sub(sym, choice(self.symbols[sym]), line)
						line = part
						done = 0
			# Now search for special cases...
			for item in self._special.keys():
				while item.search(line):
					line = item.sub(self._special[item], line)
			result = result + line + "\n"
		#file.close()

		# Chop off the last carriage return, if there is one..
		if result[-1] == "\n": result = result[:-1]
		return result

	def tokenize(self, t=None):
		"""Convert text into a unique symbol to use for replacements.
			Example:
				>>> g = Grammar(None)
				>>> g.tokenize()  # default token
				'__START__'
				>>> g.tokenize("hello there")
				'__hello_there__'
			"""
		if not t: return "__START__"
		t = t.replace(" ", "_")
		t = "__" + t + "__"
		return t

	def markov_parse(self, infile):
		"""Analyze text using Markov chains, and save into current grammar.
			"infile" may be a string or a file object.
			Other parameters are controlled by self.cfg:
				chain_len

			Tests...
			General sanity check:
				>>> import pycfg
				>>> cfg = pycfg.config(program_name)
				>>> cfg.default(chain_len=1, allow_dupe_tokens=0)
				>>> g = Grammar(cfg)
				>>> g.markov_parse("See Bob run.")
				>>> print g
				__Bob__: run.
				__Bob__: run.  __START__
				__START__: See __See__
				__See__: Bob __Bob__
				>>> g.markov_parse("See Bob jump.")
				>>> print g
				__Bob__: jump.
				__Bob__: jump.  __START__
				__Bob__: run.
				__Bob__: run.  __START__
				__START__: See __See__
				__See__: Bob __Bob__

			Special case: input doesn't end on a sentence boundary.
			FIXME
				>>> g = Grammar(cfg)
				>>> g.markov_parse("Run Bob.  yo")
				>>> print g
				__Bob.__: yo
				__Run__: Bob.
				__Run__: Bob.  __Bob.__
				__Run__: Bob.  __START__
				__START__: Run __Run__

			Special case: Sentences are shorter than the chain length.
				>>> cfg.chain_len = 3
				>>> g = Grammar(cfg)
				>>> g.markov_parse("Run Bob.  Jump Bob.")
				>>> print g
				__Jump__: Bob.
				__Jump__: Bob.  __START__
				__Run_Bob._Jump__: Bob.
				__Run_Bob._Jump__: Bob.  __Bob._Jump_Bob.__
				__Run_Bob._Jump__: Bob.  __START__
				__Run_Bob.__: Jump __Jump__
				__Run_Bob.__: Jump __Run_Bob._Jump__
				__Run__: Bob.
				__Run__: Bob.  __Run_Bob.__
				__Run__: Bob.  __START__
				__START__: Jump __Jump__
				__START__: Run __Run__
		"""
		prev_all = []  # simple FIFO
		prev_dot = []  # gets reset at the end of each sentence
		prev_end = []  # kludge to handle a corner case
		if not infile: return

		def rotate(p):
			""
			#log(DATA, "  rotate(%s)" % (repr(p)))
			#log(DATA, "    prev_all: %s" % (repr(prev_all)))
			#log(DATA, "    prev_dot: %s" % (repr(prev_dot)))
			prev_all.append(p)
			prev_dot.append(p)
			prev_end[:] = []
			if ends_sentence(p):
				if len(prev_dot) < self.cfg.chain_len:
					prev_end[:] = prev_dot
				#else: prev_end[:] = []
				prev_dot[:] = []
			for prev in (prev_all, prev_dot):
				while len(prev) > self.cfg.chain_len: del prev[0]

		def ends_sentence(word):
			if word[-1:] in ".?!": return 1
			return 0

		def insert(word):
			prevs = [prev_all]
			if prev_all != prev_dot: prevs.append(prev_dot)
			for prev in prevs:
				parts = prev
				left = self.tokenize(" ".join(parts))
				space = " "

				if ends_sentence(word):
					space = "  "
					self.add_chain(left, word)
					self.add_chain(left, word + space + self.tokenize())

				start = max(0,len(prev)-self.cfg.chain_len+1)
				#parts = prev[-self.cfg.chain_len+1:] ; parts.append(word)
				parts = prev[start:] ; parts.append(word)
				next = self.tokenize(" ".join(parts))

				right = word + space + next
				self.add_chain(left, right)

				# FIXED? fails to insert left symbols shorter than chain length,
				# to catch chains from the ends of short sentences.
				if prev_end  and  len(parts) <= 1:
					log(DEBUG, " === prev_end: %s" % (prev_end))
					left = self.tokenize(" ".join(prev_end))
					right = word + space + self.tokenize(word)
					self.add_chain(left, right)

		if isinstance(infile, str): text = [infile]
		else: text = infile.readlines()
		#for line in infile.xreadlines():
		for line in text:
			parts = line.strip().split()
			log(DATA, "")
			log(DATA, "Line: " + line.strip())
			for p in parts:
				log(DATA, "Part: " + p)
				insert(p)
				rotate(p)
		# FIXED? inserts a bogus symbol from the end of the file
		self._revert_prev_sym()

	def __str__(self):
		text = ""
		lefts = self.symbols.keys()
		lefts.sort()
		for l in lefts:
			rights = list(self.symbols[l])
			rights.sort()
			for r in rights:
				text = text + "%s: %s\n" % (l, r)
		text = text[:-1]
		return text

def cmd_help(cfg, args):
	"""Shows info about commands and their use.
	Usage: help [command] [command...]"""
	if len(args) > 0:
		for a in args:
			func = globals()["cmd_%s" % a]
			func(cfg, ["--help"])
	else:
		help(*args)

def help(*args):
	if len(args) == 0:
		print "Usage: script [command] [options]"
		print "command defaults to 'madlib'"
		print "commands include:"
		prefix = "cmd_"
		commands = globals().keys() ; commands.sort()
		fmt = "    %%-%ss %%s" % (max([len(c)-len(prefix)+1 for c in commands if c[:len(prefix)] == prefix]))
		for g in commands:
			if g[:len(prefix)] == prefix:
				try: summary = globals()[g].__doc__.split("\n")[0]
				except: summary = "[undocumented]"
				print fmt % (g[len(prefix):], summary)
	else:
		for a in args:
			try:
				func = globals()["cmd_%s" % a]
				if func.__doc__: print func.__doc__
				else: print "No documentation for %s" % (a)
			except:
				print "Invalid help topic"

def cmd_madlib(cfg, args):
	"""Generate random phrases from a grammar.
	The default story is "__START__"
	"""
	usage="usage: %prog madlib grammar [options]"

	cfg.default(story_path=None)
	cfg.default(grammar_path=None)

	from optparse import OptionParser
	cli = OptionParser(usage, version=program_version,
			description=cmd_madlib.__doc__)
	cli.add_option("-s", "--story", dest="story_path", default=cfg.story_path,
			action="store", metavar="PATH",
			help="load story from PATH [def: %s]" % (cfg.story_path))
	cli.add_option("-g", "--grammar", dest="grammar_path", default=cfg.grammar_path,
			action="store", metavar="PATH",
			help="load grammar data from PATH [def: %s]" % (cfg.grammar_path))
	cli.add_option("-v", "--verbose", default=cfg.verbose, action="count",
			help="increase chattiness by 1 [def: %s, max: %s]" % (cfg.verbose, LOGLEVELS-1))
	opts, args = cli.parse_args(args)

	cfg.merge_opts(opts)

	if len(args) == 2:
		cfg.grammar_path = args[0]
		cfg.story_path = args[1]
	elif len(args) == 1:
		cfg.grammar_path = args[0]
	elif (not cfg.grammar_path) or (len(args) > 2):
		cli.print_help()
		return

	g = Grammar(cfg)
	g.load(cfg.grammar_path)
	text = g.madlib(cfg.story_path)
	print text

def cmd_babble(cfg, args):
	"""Analyze text and output a grammar based on it.
	"""
	usage="usage: %prog babble [options]"

	cfg.default(inpath="-", outpath="-")
	cfg.default(chain_len=1)

	from optparse import OptionParser
	cli = OptionParser(usage, version=program_version,
			description=cmd_babble.__doc__)
	cli.add_option("-i", "--in", dest="inpath", default=cfg.inpath,
			action="store", metavar="PATH",
			help="analyze text from PATH [def: %s]" % (cfg.inpath))
	cli.add_option("-o", "--out", dest="outpath", default=cfg.outpath,
			action="store", metavar="PATH",
			help="save grammar data to PATH [def: %s]" % (cfg.outpath))
	cli.add_option("-l", "--chain-len", dest="chain_len", default=cfg.chain_len,
			action="store", type="int", metavar="LEN",
			help="use Markov chains of length LEN [def: %s]" % (cfg.chain_len))
	cli.add_option("-u", "--unique", dest="allow_dupe_tokens", default=cfg.allow_dupe_tokens,
			action="store_false",
			help="only store one of each token [def: %s]" % (not cfg.allow_dupe_tokens))
	cli.add_option("-r", "--repeat", dest="allow_dupe_tokens",
			action="store_true",
			help="allow repeated tokens [def: %s]" % (not not cfg.allow_dupe_tokens))
	cli.add_option("-v", "--verbose", default=cfg.verbose, action="count",
			help="increase chattiness by 1 [def: %s, max: %s]" % (cfg.verbose, LOGLEVELS-1))
	opts, args = cli.parse_args(args)

	cfg.merge_opts(opts)

	import sys
	g = Grammar(cfg)
	if cfg.inpath in [None, "", "-"]: infile = sys.stdin
	else: infile = open(cfg.inpath, "rb")
	g.markov_parse(infile)
	g.save(cfg.outpath)

def cmd_chat(cfg, args):
	"""Converse interactively.
	"""
	usage="usage: %prog chat [options] [inpath [outpath]]"

	cfg.default(inpath=None, outpath=None)
	cfg.default(chain_len=1)
	cfg.default(interactive_mode=1)

	from optparse import OptionParser
	cli = OptionParser(usage, version=program_version,
			description=cmd_babble.__doc__)
	cli.add_option("-i", "--in", dest="inpath", default=cfg.inpath,
			action="store", metavar="PATH",
			help="resume conversation saved in PATH [def: %s]" % (cfg.inpath))
	cli.add_option("-o", "--out", dest="outpath", default=cfg.outpath,
			action="store", metavar="PATH",
			help="save conversation data to PATH [def: same as inpath]")
	cli.add_option("-l", "--chain-len", dest="chain_len", default=cfg.chain_len,
			action="store", type="int", metavar="LEN",
			help="use Markov chains of length LEN [def: %s]" % (cfg.chain_len))
	cli.add_option("-u", "--unique", dest="allow_dupe_tokens", default=cfg.allow_dupe_tokens,
			action="store_false",
			help="only store one of each token [def: %s]" % (not cfg.allow_dupe_tokens))
	cli.add_option("-r", "--repeat", dest="allow_dupe_tokens",
			action="store_true",
			help="allow repeated tokens [def: %s]" % (not not cfg.allow_dupe_tokens))
	cli.add_option("-v", "--verbose", default=cfg.verbose, action="count",
			help="increase chattiness by 1 [def: %s, max: %s]" % (cfg.verbose, LOGLEVELS-1))
	opts, args = cli.parse_args(args)

	cfg.merge_opts(opts)

	#if cfg.inpath and not cfg.outpath: cfg.outpath=cfg.inpath

	if args:
		if len(args) == 1:
			cfg.inpath = cfg.outpath = args[0]
		elif len(args) == 2:
			cfg.outpath = args[1]
		else:
			cli.print_help()
			return

	import sys, os
	g = Grammar(cfg)
	if cfg.inpath  and  os.path.exists(cfg.inpath):
		print "Loading earlier conversation... %s" % (cfg.inpath)
		g.load(cfg.inpath)
	pfmt = "<%s> "
	uprompt = "%10s" % (pfmt % ("You"))
	cprompt = "%10s" % (pfmt % ("madlib"))
	print "Hello.  Talk to me.  I start slow, but I learn quickly."
	print "Type 'exit' to stop."
	try: import readline
	except: pass
	while 1:
		try:
			text = raw_input(uprompt)
			if text == "exit": break
		except EOFError:
			print ""
			break
		except KeyboardInterrupt:
			print "\nAbort.  (conversation not saved)"
			return
		g.markov_parse(text)
		reply = g.madlib()
		print cprompt + reply
	print "Thank you for the conversation."
	if not cfg.outpath:
		print "If you would like to save this conversation, enter a file name:"
		try: cfg.outpath = raw_input()
		except: pass
	if cfg.outpath:
		print "I will save this chat, so we can continue later."
		g.save(cfg.outpath)
		print "Saved conversation to: %s" % (cfg.outpath)

def cmd_warble(cfg, args):
	"""Analyze a dictionary and output a grammar based on it.
	"""
	cfg.default(chain_len=3, allow_dupe_tokens=0)
	cfg.default(inpath="-", outpath="-")

	usage="usage: %prog warble [options]"
	from optparse import OptionParser
	cli = OptionParser(usage, version=program_version,
			description=cmd_warble.__doc__)
	cli.add_option("-i", "--in", dest="inpath", default=cfg.inpath,
			action="store", metavar="PATH",
			help="analyze words from PATH [def: %s]" % (cfg.inpath))
	cli.add_option("-o", "--out", dest="outpath", default=cfg.outpath,
			action="store", metavar="PATH",
			help="save grammar data to PATH [def: %s]" % (cfg.outpath))
	cli.add_option("-l", "--chain-len", dest="chain_len", default=cfg.chain_len,
			action="store", type="int", metavar="LEN",
			help="use Markov chains of length LEN [def: %s]" % (cfg.chain_len))
	cli.add_option("-u", "--unique", dest="allow_dupe_tokens", default=cfg.allow_dupe_tokens,
			action="store_false",
			help="only store one of each token [def: %s]" % (not cfg.allow_dupe_tokens))
	cli.add_option("-r", "--repeat", dest="allow_dupe_tokens",
			action="store_true",
			help="allow repeated tokens [def: %s]" % (not not cfg.allow_dupe_tokens))
	cli.add_option("-v", "--verbose", default=cfg.verbose, action="count",
			help="increase chattiness by 1 [def: %s, max: %s]" % (cfg.verbose, LOGLEVELS-1))

	opts, args = cli.parse_args(args)

	cfg.merge_opts(opts)

	import sys
	if cfg.inpath in [None, "", "-"]: infile = sys.stdin
	else: infile = open(cfg.inpath, "rb")

	if cfg.outpath in [None, "", "-"]: outfile = sys.stdout
	else: outfile = open(cfg.outpath, "wb")

	return warble(cfg, outfile, infile)

def make_warble_chains(cfg, infile):
	"does most of the work for warble mode"
	#print "make_warble_chains(%s, %s)" % (infile, chain_len)

	# will hold a hash of lists
	chains = {}

	def add(token, letter):
		#print "  %s -> %s" % (token, letter)
		try:
			if cfg.allow_dupe_tokens:
				chains[token].append(letter)
			else:
				if letter not in chains[token]:
					chains[token].append(letter)
		except:
			chains[token] = [letter]

	for line in infile.xreadlines():
		line = line[:-1]
		#print "line: %s" % (line)
		token = ""
		next = ""
		for letter in line:
			next = token + letter
			next = next[-cfg.chain_len:]
			if token == "":
				add("__WORD__", letter)
			else:
				add(token, next)
			token = next
		if token != "":
			add(token, "")

	return chains

def warble(cfg, outfile, dictfile):
	log(INFO, "Loading: %s" % cfg.inpath)
	chains = make_warble_chains(cfg, dictfile)

	log(INFO, "Saving: %s" % cfg.outpath)
	outfile.write(":::__START__\n__WORD__\n__WORD__ __START__\n\n")
	for k in chains.keys():
		if k[0] == "_":
			outfile.write(":::%s\n" % (k))
			for item in chains[k]:
				outfile.write("_%s_\n" % (item))
			outfile.write("\n")
		else:
			outfile.write(":::_%s_\n" % (k))
			for item in chains[k]:
				if item:
					outfile.write("%s_%s_\n" % (k[-1], item))
				else:
					outfile.write("%s\n" % (k[-1]))
			outfile.write("\n")

def cmd_unittest(cfg, args):
	"Run internal tests."
	if args and args[0] in ["-h", "--help"]:
		print "usage: %s unittest [options]" % (program_name)
		print cmd_unittest.__doc__
		print "options:"
		print "  -h, --help  Print this help text."
		print "  -v          Run in verbose mode."
		pass
	else:
		failed, total = _test()
		print "%s/%s tests passed." % (total-failed, total)

def _test():
	import doctest
	return doctest.testmod()

def run(args):
	if len(args) < 1:
		help()
		return 0

	global cfg
	import pycfg
	cfg = pycfg.config(program_name)
	cfg.default(verbose=0, mode="madlib")
	cfg.default(allow_dupe_tokens=1)
	cfg.default(make_backups=1)
	cfg.load()

	modes = { # translate some options
		"madlib": "madlib",
		"-m": "madlib",
		"--madlib": "madlib",
		"babble": "babble",
		"-b": "babble",
		"--babble": "babble",
		"chat": "chat",
		"-c": "chat",
		"--chat": "chat",
		"warble": "warble",
		"-w": "warble",
		"--warble": "warble",
		"help": "help",
		"-h": "help",
		"--help": "help",
		"unittest": "unittest",
		"--unit-test": "unittest",
	}

	try:
		mode = modes[args[0]]
		args = args[1:]
	except:
		mode = "madlib"

	func = globals()["cmd_" + mode]
	return func(cfg, args)

if __name__ == "__main__":
	import sys
	run(sys.argv[1:])
